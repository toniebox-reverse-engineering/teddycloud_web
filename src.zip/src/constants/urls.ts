export const telegramGroupUrl = "https://t.me/toniebox_reverse_engineering";
export const forumUrl = "https://forum.revvox.de/";
export const gitHubUrl = "https://github.com/toniebox-reverse-engineering";
export const gitHubSponsoringUrl = "https://github.com/sponsors/toniebox-reverse-engineering";
export const gitHubRepositoriesUrl = "https://github.com/toniebox-reverse-engineering/repositories";
export const gitHubTCReleasesUrl =
    "https://github.com/toniebox-reverse-engineering/teddycloud/releases/";
export const gitHubTCCommitTreeBaseUrl =
    "https://github.com/toniebox-reverse-engineering/teddycloud/tree/";
export const gitHubTCContributorsUrl =
    "https://github.com/toniebox-reverse-engineering/teddycloud/graphs/contributors";
export const gitHubTCwebContributorsUrl =
    "https://github.com/toniebox-reverse-engineering/teddycloud_web/graphs/contributors";
export const wikiUrl = "https://tonies-wiki.revvox.de/docs/tools/teddycloud/";
export const RadioBrowserServerAPIUrlListUrl = "https://all.api.radio-browser.info/json/servers";
export const RadioBrowserFallBackUrl = "https://de2.api.radio-browser.info/json";
