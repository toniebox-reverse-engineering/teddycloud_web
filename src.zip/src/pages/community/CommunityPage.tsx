import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Typography } from "antd";

import { forumUrl, gitHubUrl, telegramGroupUrl, wikiUrl } from "../../constants/urls";

import BreadcrumbWrapper, {
    StyledContent,
    StyledLayout,
    StyledSider,
} from "../../components/common/StyledComponents";
import { CommunitySubNav } from "../../components/community/CommunitySubNav";
import { ExportOutlined } from "@ant-design/icons";

const { Paragraph } = Typography;

export const CommunityPage = () => {
    const { t } = useTranslation();

    return (
        <>
            <StyledSider>
                <CommunitySubNav />
            </StyledSider>
            <StyledLayout>
                <BreadcrumbWrapper
                    items={[
                        { title: <Link to="/">{t("home.navigationTitle")}</Link> },
                        { title: t("community.navigationTitle") },
                    ]}
                />
                <StyledContent>
                    <h1>{t("community.title")}</h1>
                    <Paragraph>
                        <h2>{t("community.community.getInvolved")}</h2>
                        {t("community.community.getInvolvedText1")}
                    </Paragraph>
                    <Paragraph>
                        <Paragraph>{t("community.community.getInvolvedText2")}</Paragraph>
                        <ul>
                            <li>
                                <Link to={gitHubUrl} target="_blank" rel="noopener noreferrer">
                                    GitHub {<ExportOutlined />}
                                </Link>
                                <ul>
                                    <li>{t("community.community.github")}</li>
                                </ul>
                            </li>
                            <li>
                                <Link
                                    to={telegramGroupUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Telegram Chat {<ExportOutlined />}
                                </Link>
                                <ul>
                                    <li>{t("community.community.telegram")}</li>
                                </ul>
                            </li>
                            <li>
                                <Link to={forumUrl} target="_blank" rel="noopener noreferrer">
                                    Discourse Forum {<ExportOutlined />}
                                </Link>
                                <ul>
                                    <li>{t("community.community.discourse")}</li>
                                </ul>
                            </li>
                            <li>
                                <Link to={wikiUrl} target="_blank" rel="noopener noreferrer">
                                    TeddyCloud Wiki {<ExportOutlined />}
                                </Link>
                                <ul>
                                    <li>{t("community.community.teddyCloudWiki")}</li>
                                </ul>
                            </li>
                        </ul>
                    </Paragraph>
                </StyledContent>
            </StyledLayout>
        </>
    );
};
