import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { MenuProps } from "antd";
import {
    ContainerOutlined,
    ExportOutlined,
    HeartOutlined,
    HomeOutlined,
    WifiOutlined,
} from "@ant-design/icons";

import { useTeddyCloud } from "../../provider/TeddyCloudProvider";
import { StyledSubMenu } from "../common/StyledComponents";
import { gitHubSponsoringUrl } from "../../constants/urls";
import { TeddyCloudSection } from "../../types/pluginsMetaTypes";

export const HomeSubNav = () => {
    const { t, i18n } = useTranslation();
    const { setNavOpen, setSubNavOpen, setCurrentTCSection, plugins } = useTeddyCloud();
    const currentLanguage = i18n.language;

    useEffect(() => {
        setCurrentTCSection(t("home.navigationTitle"));
    }, [currentLanguage]);

    const pluginItems = plugins
        .filter((p) => p.teddyCloudSection === TeddyCloudSection.Home && !p.hideInNav)
        .map((plugin) => ({
            key: `plugin-${plugin.pluginId}`,
            label: (
                <Link
                    to={
                        plugin.standalone
                            ? `/plugin/${plugin.pluginId}`
                            : `/home/plugin/${plugin.pluginId}`
                    }
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                    target={plugin.standalone ? "_blank" : "_self"}
                >
                    {plugin.pluginName}
                    {plugin.standalone ? (
                        <ExportOutlined
                            style={{ marginLeft: 2, fontSize: 6, bottom: 6, position: "relative" }}
                        />
                    ) : (
                        ""
                    )}
                </Link>
            ),
            icon: React.createElement(plugin.icon),
            title: plugin.pluginName,
        }));

    const subnav: MenuProps["items"] = [
        {
            key: "home",
            label: (
                <Link
                    to="/"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("home.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(HomeOutlined),
            title: t("home.navigationTitle"),
        },
        {
            key: "features",
            label: (
                <Link
                    to="/home/features"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("home.features.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(ContainerOutlined),
            title: t("home.features.navigationTitle"),
        },
        {
            key: "statistics",
            label: (
                <Link
                    to="/home/stats"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("home.stats.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(WifiOutlined),
            title: t("home.stats.navigationTitle"),
        },
        {
            key: "sponsor",
            label: (
                <Link
                    to={gitHubSponsoringUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("home.sponsor.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(HeartOutlined),
            title: t("home.sponsor.navigationTitle"),
        },
        ...pluginItems,
        {
            key: "hiddenMeeting",
            label: (
                <Link
                    to="/home/tonieMeeting"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                ></Link>
            ),
        },
    ];

    return (
        <StyledSubMenu mode="inline" selectedKeys={[]} defaultOpenKeys={["sub"]} items={subnav} />
    );
};
