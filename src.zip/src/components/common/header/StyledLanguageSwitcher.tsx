import { useTranslation } from "react-i18next";
import { Dropdown, Space, Tag } from "antd";
import { GlobalOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";
import { LANGUAGES } from "virtual:languages";

export const StyledLanguageSwitcher = () => {
    const { t, i18n } = useTranslation();

    const LANGS = LANGUAGES.map((key) => ({
        key,
        label: key.toUpperCase(),
    }));

    const currentLanguage = i18n.language;
    const currentLabel =
        LANGS.find((l) => l.key === currentLanguage.substring(0, 2))?.label ?? currentLanguage;

    return (
        <div style={{ marginRight: 8 }}>
            <Space style={{ marginRight: -8 }}>
                <Dropdown
                    trigger={["click"]}
                    menu={{
                        items: LANGS.map((l) => ({
                            ...l,
                            onClick: () => i18n.changeLanguage(l.key),
                        })),
                    }}
                >
                    <Link to="/" onClick={(e) => e.preventDefault()} title={t("language.change")}>
                        <Tag
                            style={{
                                fontSize: "unset",
                                backgroundColor: "transparent",
                                border: 0,
                                color: "white",
                            }}
                        >
                            <GlobalOutlined /> {currentLabel.toUpperCase()}
                        </Tag>
                    </Link>
                </Dropdown>
            </Space>
        </div>
    );
};
