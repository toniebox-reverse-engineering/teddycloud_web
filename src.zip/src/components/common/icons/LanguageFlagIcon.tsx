import React, { useEffect, useState } from "react";

async function loadFlagAsset(code: string): Promise<string | null> {
    try {
        const mod = await import(`../../../assets/country-flags-3x2/${code}.svg`);
        return mod.default;
    } catch {
        return null;
    }
}

interface LanguageFlagIconProps extends React.ImgHTMLAttributes<HTMLImageElement> {
    name: string;
    height?: number | string;
}

export const LanguageFlagIcon: React.FC<LanguageFlagIconProps> = ({
    name,
    height = 24,
    ...imgProps
}) => {
    const [flagUrl, setFlagUrl] = useState<string | null>(null);

    useEffect(() => {
        let active = true;

        const load = async () => {
            if (!name) {
                const fallback = await loadFlagAsset("UNKNOWN");
                if (active) setFlagUrl(fallback);
                return;
            }

            const normalized = name.toUpperCase();
            const flag = await loadFlagAsset(normalized);

            if (active) {
                setFlagUrl(flag ?? (await loadFlagAsset("UNKNOWN")));
            }
        };

        load();
        return () => {
            active = false;
        };
    }, [name]);

    if (!flagUrl) return null;

    return <img src={flagUrl} height={height} alt={`Flag ${name}`} {...imgProps} />;
};

export const languageOptions = [
    "de-de",
    "en-gb",
    "en-us",
    "es-es",
    "fr-fr",
    "it-it",
    "nl-be",
    "nl-nl",
    "pl-pl",
    "pt-pt",
    "tr-tr",
    "ca-ad",
    "ar-ae",
    "af-af",
    "en-ag",
    "en-ai",
    "sq-al",
    "hy-am",
    "pt-ao",
    "xx-aq",
    "es-ar",
    "en-as",
    "de-at",
    "en-au",
    "nl-aw",
    "sv-ax",
    "az-az",
    "bs-ba",
    "en-bb",
    "bn-bd",
    "fr-bf",
    "bg-bg",
    "ar-bh",
    "en-bi",
    "fr-bj",
    "fr-bl",
    "en-bm",
    "ms-bn",
    "es-bo",
    "nl-bq",
    "pt-br",
    "en-bs",
    "dz-bt",
    "no-bv",
    "en-bw",
    "be-by",
    "en-bz",
    "en-ca",
    "en-cc",
    "fr-cd",
    "fr-cf",
    "fr-cg",
    "de-ch",
    "fr-ci",
    "en-ck",
    "es-cl",
    "fr-cm",
    "zh-cn",
    "es-co",
    "es-cr",
    "es-cu",
    "pt-cv",
    "nl-cw",
    "en-cx",
    "el-cy",
    "cs-cz",
    "fr-dj",
    "da-dk",
    "en-dm",
    "es-do",
    "ar-dz",
    "es-ec",
    "et-ee",
    "ar-eg",
    "ar-eh",
    "ti-er",
    "am-et",
    "xx-eu",
    "fi-fi",
    "en-fj",
    "en-fk",
    "en-fm",
    "fo-fo",
    "fr-ga",
    "en-gd",
    "ka-ge",
    "fr-gf",
    "en-gg",
    "en-gh",
    "en-gi",
    "kl-gl",
    "en-gm",
    "fr-gn",
    "fr-gp",
    "es-gq",
    "el-gr",
    "en-gs",
    "es-gt",
    "en-gu",
    "pt-gw",
    "en-gy",
    "zh-hk",
    "en-hm",
    "es-hn",
    "hr-hr",
    "fr-ht",
    "hu-hu",
    "es-ic",
    "id-id",
    "en-ie",
    "he-il",
    "en-im",
    "hi-in",
    "en-io",
    "ar-iq",
    "fa-ir",
    "is-is",
    "en-je",
    "en-jm",
    "ar-jo",
    "ja-jp",
    "sw-ke",
    "ky-kg",
    "km-kh",
    "en-ki",
    "ar-km",
    "en-kn",
    "ko-kp",
    "ko-kr",
    "ar-kw",
    "en-ky",
    "kk-kz",
    "lo-la",
    "ar-lb",
    "en-lc",
    "de-li",
    "si-lk",
    "en-lr",
    "en-ls",
    "lt-lt",
    "fr-lu",
    "lv-lv",
    "ar-ly",
    "ar-ma",
    "fr-mc",
    "ro-md",
    "sr-me",
    "fr-mf",
    "mg-mg",
    "en-mh",
    "mk-mk",
    "bm-ml",
    "my-mm",
    "mn-mn",
    "zh-mo",
    "en-mp",
    "fr-mq",
    "ar-mr",
    "en-ms",
    "mt-mt",
    "en-mu",
    "dv-mv",
    "en-mw",
    "es-mx",
    "ms-my",
    "pt-mz",
    "en-na",
    "fr-nc",
    "fr-ne",
    "en-nf",
    "en-ng",
    "es-ni",
    "no-no",
    "ne-np",
    "en-nr",
    "en-nu",
    "en-nz",
    "ar-om",
    "es-pa",
    "es-pe",
    "fr-pf",
    "en-pg",
    "tl-ph",
    "ur-pk",
    "fr-pm",
    "en-pn",
    "es-pr",
    "ar-ps",
    "en-pw",
    "es-py",
    "ar-qa",
    "fr-re",
    "ro-ro",
    "sr-rs",
    "ru-ru",
    "rw-kg",
    "ar-sa",
    "en-sb",
    "en-sc",
    "ar-sd",
    "sv-se",
    "en-sg",
    "en-sh",
    "sl-si",
    "no-sj",
    "sk-sk",
    "en-sl",
    "it-sm",
    "fr-sn",
    "so-so",
    "nl-sr",
    "en-ss",
    "pt-st",
    "es-sv",
    "nl-sx",
    "ar-sy",
    "en-sz",
    "en-ta",
    "en-tc",
    "fr-td",
    "fr-tf",
    "fr-tg",
    "th-th",
    "tg-tj",
    "en-tk",
    "tet-tl",
    "tk-tm",
    "ar-tn",
    "en-to",
    "en-tt",
    "en-tv",
    "zh-tw",
    "sw-tz",
    "uk-ua",
    "en-ug",
    "en-um",
    "es-uy",
    "uz-uz",
    "it-va",
    "en-vc",
    "es-ve",
    "en-vg",
    "en-vi",
    "vi-vn",
    "en-vu",
    "fr-wf",
    "en-ws",
    "sq-xk",
    "ar-ye",
    "fr-yt",
    "en-za",
    "en-zm",
    "en-zw",
];

export type LanguageCode = (typeof languageOptions)[number];

export function toLanguageCode(input?: string): LanguageCode | "" {
    const value = String(input ?? "").trim();
    if (!value) return "";
    return languageOptions.includes(value as LanguageCode) ? (value as LanguageCode) : "";
}

export function getFlagCountryCodeFromLanguage(input?: string): string {
    const languageCode = toLanguageCode(input);
    if (!languageCode) return "UNKNOWN";
    const parts = languageCode.split("-");
    if (parts.length > 1 && parts[1]) return parts[1].toUpperCase();
    return "UNKNOWN";
}
