import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Button, Modal, theme } from "antd";

import { SelectFileFileBrowser } from "../../filebrowser/SelectFileFileBrowser";
import { TonieInfo } from "../../../../types/tonieTypes";

const { useToken } = theme;

export interface SelectAudioFileResult {
    path: string;
    audioId?: string;
    hash?: string;
    /** Start of each track in seconds, from the TAF header. */
    trackSeconds?: number[];
    /** Total audio length in seconds, when the backend provides it. */
    lengthSeconds?: number;
    /** Model info resolved by the backend from the TAF header (fileIndexV2 tonieInfo). */
    tonieInfo?: Pick<TonieInfo, "model" | "series" | "episode">;
}

/**
 * Select audio files (.taf, .tap) from library (lib://).
 * Used by TonieCard and CustomModelEditor. Kept separate from image selection.
 */
interface SelectAudioModalProps {
    open: boolean;
    onClose: () => void;
    onSelect: (result: SelectAudioFileResult) => void;
    keySelectFileFileBrowser: number;
    /** When true, OK is only enabled when file has valid TAF header. For tonies.custom.json. */
    requireTafHeader?: boolean;
    /** Initial path. E.g. lib://path or path. */
    initialPath?: string;
    /** Optional title override */
    title?: string;
    zIndex?: number;
}

export const SelectAudioModal: React.FC<SelectAudioModalProps> = ({
    open,
    onClose,
    onSelect,
    keySelectFileFileBrowser,
    requireTafHeader = false,
    initialPath = "",
    title: titleProp,
    zIndex = undefined,
}) => {
    const { t } = useTranslation();
    const { token } = useToken();
    const [selectedFile, setSelectedFile] = useState<SelectAudioFileResult | null>(null);

    const resolveSelectedFile = (files: any[], path: string): SelectAudioFileResult | null => {
        if (!files || files.length !== 1) return null;
        const file = files[0];
        const normalizedPath = path === "" || path.endsWith("/") ? path : `${path}/`;
        const filePath = `lib://${normalizedPath}${file.name}`;
        const tonieInfo = file?.tonieInfo
            ? {
                  model: String(file.tonieInfo.model ?? "").trim(),
                  series: String(file.tonieInfo.series ?? "").trim(),
                  episode: String(file.tonieInfo.episode ?? "").trim(),
              }
            : undefined;

        if (!requireTafHeader) {
            return { path: filePath, tonieInfo };
        }

        const audioIdRaw = file?.tafHeader?.audioId;
        const hashRaw = file?.tafHeader?.sha1Hash;
        if (audioIdRaw == null || !hashRaw) return null;

        return {
            path: filePath,
            audioId: String(audioIdRaw).trim(),
            hash: String(hashRaw).trim(),
            trackSeconds: file?.tafHeader?.trackSeconds,
            lengthSeconds: file?.tafHeader?.lengthSeconds,
            tonieInfo,
        };
    };

    useEffect(() => {
        if (open) setSelectedFile(null);
    }, [open]);

    const handleFileSelectChange = (files: any[], path: string, _special: string) => {
        setSelectedFile(resolveSelectedFile(files, path));
    };

    const canConfirm =
        selectedFile &&
        (!requireTafHeader || (selectedFile.audioId != null && selectedFile.hash != null));

    const handleConfirm = () => {
        if (selectedFile && canConfirm) {
            onSelect(selectedFile);
            setSelectedFile(null);
            onClose();
        }
    };

    const handleCancel = () => {
        setSelectedFile(null);
        onClose();
    };

    const defaultTitle = requireTafHeader
        ? t("tonies.customEditor.audio.selectFromLibrary", {
              library: t("tonies.library.title"),
          })
        : t("tonies.selectFileModal.selectFile");
    const title = titleProp ?? defaultTitle;
    // If TAF header data is required (audio_id/hash), only .taf is valid.
    // .tap does not provide the required header metadata for this flow.
    const allowedFileTypes = requireTafHeader ? [".taf"] : [".taf", ".tap"];

    const footer = (
        <div
            style={{
                display: "flex",
                gap: 8,
                justifyContent: "flex-end",
                padding: "16px 0",
                margin: "-24px -24px -12px -24px",
                background: token.colorBgElevated,
            }}
        >
            <Button htmlType="button" onClick={handleCancel}>
                {t("tonies.selectFileModal.cancel")}
            </Button>
            <Button htmlType="button" type="primary" onClick={handleConfirm} disabled={!canConfirm}>
                {t("tonies.selectFileModal.ok")}
            </Button>
        </div>
    );

    const workingInitialPath =
        initialPath && initialPath.startsWith("lib://")
            ? initialPath.replace(/^lib:\/\//, "").replace(/[^/]+$/, "")
            : initialPath;

    return (
        <Modal
            className="sticky-footer"
            title={title}
            open={open}
            onCancel={handleCancel}
            onOk={handleConfirm}
            width="auto"
            footer={footer}
            zIndex={zIndex}
        >
            <SelectFileFileBrowser
                key={keySelectFileFileBrowser}
                initialPath={workingInitialPath}
                special="library"
                maxSelectedRows={1}
                trackUrl={false}
                filetypeFilter={allowedFileTypes}
                onFileSelectChange={handleFileSelectChange}
                onFileDoubleClick={(file, path) => {
                    const resolved = resolveSelectedFile([file], path);
                    if (!resolved) return;
                    onSelect(resolved);
                    setSelectedFile(null);
                    onClose();
                }}
            />
        </Modal>
    );
};
