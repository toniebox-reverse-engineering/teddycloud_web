import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { MenuProps } from "antd";
import {
    UserOutlined,
    SettingOutlined,
    BookOutlined,
    SoundOutlined,
    CloudUploadOutlined,
    UnorderedListOutlined,
    UserAddOutlined,
    FormatPainterOutlined,
    PlayCircleOutlined,
    ExportOutlined,
} from "@ant-design/icons";
import i18n from "../../i18n";

import { useTeddyCloud } from "../../provider/TeddyCloudProvider";
import { StyledSubMenu } from "../common/StyledComponents";
import { TeddyCloudSection } from "../../types/pluginsMetaTypes";
import { useCustomModelsEditorLauncher } from "./hooks/useCustomModelsEditorFeature";

export const ToniesSubNav = () => {
    const { t } = useTranslation();
    const { setNavOpen, setSubNavOpen, setCurrentTCSection, plugins } = useTeddyCloud();
    const { launchCustomModelsEditor } = useCustomModelsEditorLauncher();
    const [selectedKey, setSelectedKey] = useState("");
    const currentLanguage = i18n.language;

    useEffect(() => {
        setCurrentTCSection(t("tonies.tonies.navigationTitle"));
    }, [currentLanguage]);

    const pluginItems = plugins
        .filter((p) => p.teddyCloudSection === TeddyCloudSection.Tonies && !p.hideInNav)
        .map((plugin) => ({
            key: `plugin-${plugin.pluginId}`,
            label: (
                <Link
                    to={
                        plugin.standalone
                            ? `/plugin/${plugin.pluginId}`
                            : `/tonies/plugin/${plugin.pluginId}`
                    }
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                    target={plugin.standalone ? "_blank" : "_self"}
                >
                    {plugin.pluginName}
                    {plugin.standalone ? (
                        <ExportOutlined
                            style={{ marginLeft: 2, fontSize: 6, bottom: 6, position: "relative" }}
                        />
                    ) : (
                        ""
                    )}
                </Link>
            ),
            icon: React.createElement(plugin.icon),
            title: plugin.pluginName,
        }));

    const subnav: MenuProps["items"] = [
        {
            key: "tonies",
            label: (
                <Link
                    to="/tonies"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.tonies.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(UserOutlined),
            title: t("tonies.tonies.navigationTitle"),
        },
        {
            key: "library",
            label: (
                <Link
                    to="/tonies/library"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.library.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(BookOutlined),
            title: t("tonies.library.navigationTitle"),
        },
        {
            key: "tonies-audio-player",
            label: (
                <Link
                    to="/tonies/audioplayer"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.teddyaudioplayer.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(PlayCircleOutlined),
            title: t("tonies.teddyaudioplayer.navigationTitle"),
        },
        {
            key: "encoder",
            label: (
                <Link
                    to="/tonies/encoder"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.encoder.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(CloudUploadOutlined),
            title: t("tonies.encoder.navigationTitle"),
        },
        {
            key: "tap",
            label: (
                <Link
                    to="/tonies/tap"
                    style={{
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        color: "currentColor",
                    }}
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.tap.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(UnorderedListOutlined),
            title: t("tonies.tap.navigationTitle"),
        },
        {
            key: "custom-json",
            label: (
                <Link
                    to="/tonies/customeditor"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.customToniesEditorJsonEntry")}
                </Link>
            ),
            onClick: () => {
                launchCustomModelsEditor();
                setNavOpen(false);
                setSubNavOpen(false);
            },
            icon: React.createElement(UserAddOutlined),
            title: t("tonies.customToniesEditorJsonEntry"),
        },
        {
            key: "teddystudio",
            label: (
                <Link
                    to="/tonies/teddystudio"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.teddystudio.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(FormatPainterOutlined),
            title: t("tonies.teddystudio.navigationTitle"),
        },
        {
            key: "content",
            label: (
                <Link
                    to="/tonies/content"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.content.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(SoundOutlined),
            title: t("tonies.content.navigationTitle"),
        },
        {
            key: "system-sounds",
            label: (
                <Link
                    to="/tonies/system-sounds"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("tonies.system-sounds.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(SettingOutlined),
            title: t("tonies.system-sounds.navigationTitle"),
        },

        ...pluginItems,
    ];

    return (
        <StyledSubMenu
            mode="inline"
            selectedKeys={[selectedKey]}
            defaultOpenKeys={["sub"]}
            items={subnav}
        />
    );
};
