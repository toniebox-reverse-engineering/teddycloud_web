import React, { useEffect, useRef, useState } from "react";
import { Breadcrumb, Empty, InputRef } from "antd";
import { useLocation, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Record } from "../../../../types/fileBrowserTypes";

import { useTeddyCloud } from "../../../../provider/TeddyCloudProvider";
import { NotificationTypeEnum } from "../../../../types/teddyCloudNotificationTypes";

import { TeddyCloudApi } from "../../../../api";
import { defaultAPIConfig } from "../../../../config/defaultApiConfig";
import { UI_SEARCH_DEBOUNCE_MS } from "../../../../constants/numbers";

const api = new TeddyCloudApi(defaultAPIConfig());

type Mode = "fileBrowser" | "select";

interface UseFileBrowserCoreOptions {
    mode: Mode;
    special: string;
    overlay?: string;
    showDirOnly?: boolean;
    filetypeFilter?: string[];
    trackUrl?: boolean;
    initialPath?: string;
    active?: boolean;
}

interface UseFileBrowserCoreResult {
    path: string;
    setPath: React.Dispatch<React.SetStateAction<string>>;
    files: Record[];
    rebuildList: boolean;
    setRebuildList: React.Dispatch<React.SetStateAction<boolean>>;
    loading: boolean;

    /** Debounced value applied to table column filter. */
    filterText: string;
    /** Immediate input value (typing). */
    filterInputText: string;
    filterFieldAutoFocus: boolean;
    setFilterFieldAutoFocus: React.Dispatch<React.SetStateAction<boolean>>;
    handleFilterChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    clearFilterField: () => void;
    handleFilterFieldInputFocus: () => void;
    handleFilterFieldInputBlur: () => void;
    inputFilterRef: React.RefObject<InputRef | null>;

    generateBreadcrumbs: (currentPath: string) => React.ReactNode;

    buildDirPath: (dirPath: string) => string;
    buildContentUrl: (
        fileName: string,
        options?: { ogg?: boolean; path?: string; special?: string },
    ) => string;

    defaultSorter: (a: any, b: any, dataIndex: string | string[]) => number;
    dirNameSorter: (a: any, b: any) => number;

    noData: React.ReactNode | null;
    parentRef: React.RefObject<HTMLDivElement | null>;
}

export const useFileBrowserCore = ({
    mode,
    special,
    overlay = "",
    showDirOnly = false,
    filetypeFilter = [],
    trackUrl = true,
    initialPath: initialPathProp = "",
    active = true,
}: UseFileBrowserCoreOptions): UseFileBrowserCoreResult => {
    const { t } = useTranslation();
    const { addNotification } = useTeddyCloud();

    const location = useLocation();
    const navigate = useNavigate();

    const [files, setFiles] = useState<Record[]>([]);

    // URL path is only relevant for mode="fileBrowser"
    const queryParams = new URLSearchParams(location.search);
    const initialPathFromUrl = mode === "fileBrowser" ? queryParams.get("path") || "" : "";

    // Resolve initial path without "root first" flash
    const resolvedInitialPath = (() => {
        if (mode === "fileBrowser") {
            const source = trackUrl ? initialPathFromUrl : "";
            const raw = source || initialPathProp || "";
            return raw ? raw.split("/").map(encodeURIComponent).join("/") : "";
        } else {
            return initialPathProp || "";
        }
    })();

    const [path, setPath] = useState<string>(() => resolvedInitialPath);
    const [rebuildList, setRebuildList] = useState<boolean>(false);

    const [filterInputText, setFilterInputText] = useState<string>("");
    const [filterText, setFilterText] = useState<string>("");
    const [filterFieldAutoFocus, setFilterFieldAutoFocus] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(true);

    const inputFilterRef = useRef<InputRef>(null);
    const cursorPositionFilterRef = useRef<number | null>(null);
    const parentRef = useRef<HTMLDivElement | null>(null);

    // Prevent infinite fallback loops
    const fallbackInProgressRef = useRef(false);

    // Only the latest directory request may update FileBrowser state.
    const requestIdRef = useRef(0);

    // If initialPathProp changes, apply it in select-mode
    const lastAppliedInitialPathRef = useRef<string>(resolvedInitialPath);
    useEffect(() => {
        if (mode !== "select") return;

        const next = initialPathProp || "";
        if (next === lastAppliedInitialPathRef.current) return;

        lastAppliedInitialPathRef.current = next;
        setPath(next);
        setRebuildList((prev) => !prev);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialPathProp, mode]);

    const previousOverlayRef = useRef(overlay);

    // overlay change → reset path + URL. The fetch effect below reacts to overlay directly.
    useEffect(() => {
        if (previousOverlayRef.current === overlay) return;
        previousOverlayRef.current = overlay;

        if (mode === "fileBrowser" && trackUrl) {
            const qp = new URLSearchParams(window.location.search);
            qp.set("path", "");
            const newUrl = `${window.location.pathname}?${qp.toString()}`;
            window.history.replaceState(null, "", newUrl);
        }

        setPath("");
    }, [overlay, mode, trackUrl]);

    const filetypeFilterKey = filetypeFilter.join("|");

    // fetch directory listing (SWR for custom_img: show cache first, revalidate in background)
    useEffect(() => {
        if (!active) return;

        const requestId = ++requestIdRef.current;
        const abortController = new AbortController();
        const isCurrentRequest = () =>
            requestIdRef.current === requestId && !abortController.signal.aborted;

        const apiPathParam = mode === "fileBrowser" ? path : encodeURIComponent(path);
        const activeFiletypeFilter = filetypeFilterKey ? filetypeFilterKey.split("|") : [];
        const cacheKey = `fileIndexV2:${special}:${overlay || ""}:${apiPathParam}:${showDirOnly}:${filetypeFilterKey}`;
        const useSwr = special === "custom_img";

        let hadCache = false;
        if (useSwr) {
            try {
                const cached = sessionStorage.getItem(cacheKey);
                if (cached) {
                    const parsed = JSON.parse(cached) as Record[];
                    if (Array.isArray(parsed)) {
                        setFiles(parsed);
                        setLoading(false);
                        hadCache = true;
                    }
                }
            } catch {
                /* ignore parse errors */
            }
        }
        if (!hadCache) {
            setLoading(true);
        }

        api.apiGetTeddyCloudApiRaw(
            `/api/fileIndexV2?path=${apiPathParam}&special=${special}` +
                (overlay ? `&overlay=${overlay}` : ""),
            undefined,
            { signal: abortController.signal },
        )
            .then(async (response: Response) => {
                if (!isCurrentRequest()) return null;

                // IMPORTANT: make non-2xx fail deterministically (so we can fallback)
                if (!response.ok) {
                    const err: any = new Error(`HTTP ${response.status}`);
                    err.status = response.status;
                    throw err;
                }
                return response.json();
            })
            .then((data: any) => {
                if (!isCurrentRequest() || !data) return;

                fallbackInProgressRef.current = false;

                const list: Record[] = (data.files || []) as Record[];

                const filteredList = list.filter((entry) => {
                    if (showDirOnly && !entry.isDir) return false;

                    if (activeFiletypeFilter.length > 0 && !entry.isDir) {
                        const lowerName = entry.name.toLowerCase();
                        return activeFiletypeFilter.some((suffix) =>
                            lowerName.endsWith(suffix.toLowerCase()),
                        );
                    }
                    return true;
                });

                setFiles(filteredList);

                if (useSwr) {
                    try {
                        sessionStorage.setItem(cacheKey, JSON.stringify(filteredList));
                    } catch {
                        /* ignore quota errors */
                    }
                }
            })
            .catch((error: any) => {
                if (
                    !isCurrentRequest() ||
                    abortController.signal.aborted ||
                    error?.name === "AbortError"
                ) {
                    return;
                }

                // If the requested path is invalid/unavailable -> go back to root
                // Do this only once to avoid loops if root is also failing.
                const canFallback = path !== "" && !fallbackInProgressRef.current;

                const status = typeof error?.status === "number" ? error.status : undefined;
                const looksLikeNotFound =
                    status === 404 ||
                    status === 400 ||
                    /not\s*found/i.test(String(error?.message ?? "")) ||
                    /failed to load dir content/i.test(String(error ?? ""));

                if (canFallback && (looksLikeNotFound || status === undefined)) {
                    fallbackInProgressRef.current = true;

                    addNotification(
                        NotificationTypeEnum.Warning,
                        t("fileBrowser.messages.errorFetchingDirContent"),
                        t("fileBrowser.messages.errorFetchingDirContentDetails", {
                            path: path || "/",
                        }) + error,
                        t("fileBrowser.title"),
                    );

                    // reset to root
                    setPath("");

                    if (mode === "fileBrowser" && trackUrl) {
                        const qp = new URLSearchParams(window.location.search);
                        qp.set("path", "");
                        navigate(`?${qp.toString()}`, { replace: true });
                    }
                    return;
                }
            })
            .finally(() => {
                if (isCurrentRequest()) {
                    setLoading(false);
                }
            });

        return () => {
            abortController.abort();
        };
    }, [active, path, special, overlay, showDirOnly, filetypeFilterKey, rebuildList]);

    useEffect(() => {
        const timer = window.setTimeout(
            () => setFilterText(filterInputText),
            UI_SEARCH_DEBOUNCE_MS,
        );
        return () => window.clearTimeout(timer);
    }, [filterInputText]);

    // restore caret position in filter field
    useEffect(() => {
        if (cursorPositionFilterRef.current !== null && inputFilterRef.current) {
            inputFilterRef.current.setSelectionRange(
                cursorPositionFilterRef.current,
                cursorPositionFilterRef.current,
            );
        }
    }, [filterInputText]);

    // filter handlers
    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFilterInputText(e.target.value);
        cursorPositionFilterRef.current = e.target.selectionStart;
        setFilterFieldAutoFocus(true);
    };

    const clearFilterField = () => {
        setFilterInputText("");
        setFilterText("");
        cursorPositionFilterRef.current = 0;
    };

    const handleFilterFieldInputFocus = () => {
        setFilterFieldAutoFocus(true);
    };

    const handleFilterFieldInputBlur = () => {
        setFilterFieldAutoFocus(false);
    };

    // breadcrumbs
    const handleBreadcrumbClick = (dirPath: string) => {
        if (mode === "fileBrowser" && trackUrl) {
            navigate(`?path=${dirPath}`);
        }
        if (path === dirPath) {
            setRebuildList((prev) => !prev);
        }
        setFilterFieldAutoFocus(false);
        setPath(dirPath);
    };

    const generateBreadcrumbs = (currentPath: string) => {
        const pathArray = currentPath.split("/").filter((segment) => segment);

        const breadcrumbItems = [
            {
                title: (
                    <span style={{ cursor: "pointer" }} onClick={() => handleBreadcrumbClick("")}>
                        {t("fileBrowser.root")}
                    </span>
                ),
                key: "/",
            },
        ];

        pathArray.forEach((segment, index) => {
            const segmentPath =
                mode === "fileBrowser"
                    ? `/${pathArray.slice(0, index + 1).join("/")}`
                    : `${pathArray.slice(0, index + 1).join("/")}`;

            breadcrumbItems.push({
                title: (
                    <span
                        style={{ cursor: "pointer" }}
                        onClick={() => handleBreadcrumbClick(segmentPath)}
                    >
                        {decodeURIComponent(segment)}
                    </span>
                ),
                key: segmentPath || "/",
            });
        });

        return <Breadcrumb items={breadcrumbItems} />;
    };

    // sorting helpers
    const getFieldValue = (obj: any, keys: string[]) => {
        return keys.reduce((acc, currentKey) => {
            if (acc && acc[currentKey] !== undefined) {
                return acc[currentKey];
            }
            return undefined;
        }, obj);
    };

    const defaultSorter = (a: any, b: any, dataIndex: string | string[]) => {
        if (a?.name === "..") return -1;
        if (b?.name === "..") return 1;

        const fieldA = Array.isArray(dataIndex) ? getFieldValue(a, dataIndex) : a[dataIndex];
        const fieldB = Array.isArray(dataIndex) ? getFieldValue(b, dataIndex) : b[dataIndex];

        if (fieldA === undefined && fieldB === undefined) return 0;
        if (fieldA === undefined) return 1;
        if (fieldB === undefined) return -1;

        if (typeof fieldA === "string" && typeof fieldB === "string")
            return fieldA.localeCompare(fieldB);
        if (typeof fieldA === "number" && typeof fieldB === "number") return fieldA - fieldB;

        // eslint-disable-next-line no-console
        console.log("Unsupported types for sorting:", a, b, dataIndex, fieldA, fieldB);
        return 0;
    };

    const dirNameSorter = (a: any, b: any) => {
        if (a?.name === "..") return -1;
        if (b?.name === "..") return 1;
        if (a.isDir === b.isDir) return defaultSorter(a, b, "name");
        return a.isDir ? -1 : 1;
    };

    const buildDirPath = (dirPath: string): string => {
        if (dirPath === "..") {
            if (!path) return "";
            if (mode === "fileBrowser") {
                return path
                    .split("/")
                    .map(decodeURIComponent)
                    .slice(0, -1)
                    .map(encodeURIComponent)
                    .join("/");
            }
            return path.split("/").slice(0, -1).join("/");
        }

        if (mode === "fileBrowser") {
            const decodedParts = path ? path.split("/").map(decodeURIComponent) : [];
            return [...decodedParts, dirPath].map(encodeURIComponent).join("/");
        }
        return path ? `${path}/${dirPath}` : dirPath;
    };

    const buildContentUrl = (
        fileName: string,
        options?: { ogg?: boolean; path?: string; special?: string },
    ): string => {
        const { ogg = false, path: pathOverride, special: specialOverride } = options || {};

        const encodedPath =
            pathOverride !== undefined
                ? pathOverride
                      .split("/")
                      .filter(Boolean)
                      .map((segment) => encodeURIComponent(segment))
                      .join("/")
                : mode === "fileBrowser"
                  ? path || ""
                  : path
                    ? path
                          .split("/")
                          .map((segment) => encodeURIComponent(segment))
                          .join("/")
                    : "";
        const targetSpecial = specialOverride !== undefined ? specialOverride : special;
        const encodedName = encodeURIComponent(fileName);

        if (targetSpecial === "custom_img") {
            return encodedPath
                ? `/custom_img/${encodedPath}/${encodedName}`
                : `/custom_img/${encodedName}`;
        }

        let url = `/content/${encodedPath ? encodedPath + "/" : "/"}${encodedName}`;

        const params = new URLSearchParams();
        if (ogg) params.set("ogg", "true");
        if (targetSpecial) params.set("special", targetSpecial);
        if (overlay) params.set("overlay", overlay);

        const query = params.toString();
        if (query) {
            url += `?${query}`;
        }
        return url;
    };

    const noData =
        files.length === 0 && !loading ? <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} /> : null;

    return {
        path,
        setPath,
        files,
        rebuildList,
        setRebuildList,
        loading,

        filterText,
        filterInputText,
        filterFieldAutoFocus,
        setFilterFieldAutoFocus,
        handleFilterChange,
        clearFilterField,
        handleFilterFieldInputFocus,
        handleFilterFieldInputBlur,
        inputFilterRef,

        generateBreadcrumbs,

        buildDirPath,
        buildContentUrl,

        defaultSorter,
        dirNameSorter,

        noData,
        parentRef,
    };
};
