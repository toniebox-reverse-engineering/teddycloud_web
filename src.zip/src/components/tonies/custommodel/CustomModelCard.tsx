import React from "react";
import { useTranslation } from "react-i18next";
import { Card, Popconfirm, Tag, Tooltip, theme } from "antd";
import { CopyOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { toImageSrc, toPreviewableImageUrl } from "../common/utils/imagePathUtils";

export interface CustomModelCardEntry {
    model: string;
    series?: string;
    episodes?: string;
    pic?: string;
}

export interface CustomModelCardProps {
    idx: number;
    entry: CustomModelCardEntry;
    gridColumns: number;
    /** Model of the original tonie this entry takes precedence over, if any. */
    overriddenModel?: string;
    onEdit: (idx: number) => void;
    onDuplicate: (idx: number) => void;
    onDelete: (idx: number) => void;
    onPreviewClick: (url: string) => void;
}

export const CustomModelCard: React.FC<CustomModelCardProps> = ({
    idx,
    entry,
    gridColumns,
    overriddenModel,
    onEdit,
    onDuplicate,
    onDelete,
    onPreviewClick,
}) => {
    const { t } = useTranslation();
    const { token } = theme.useToken();
    const previewUrl = toPreviewableImageUrl(entry.pic);
    return (
        <div
            style={{
                flex: `0 0 calc(${100 / gridColumns}% - 16px)`,
                maxWidth: `calc(${100 / gridColumns}% - 16px)`,
            }}
        >
            <Card
                hoverable={false}
                size="small"
                style={{
                    background: token.colorBgContainerDisabled,
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                }}
                title={
                    <div style={{ overflow: "hidden", textOverflow: "ellipsis" }}>
                        {entry.series || entry.model || "-"}
                    </div>
                }
                cover={
                    <div
                        style={{ position: "relative" }}
                        onClick={() => {
                            if (previewUrl) onPreviewClick(previewUrl);
                        }}
                    >
                        {previewUrl ? (
                            <img
                                src={toImageSrc(previewUrl)}
                                alt={entry.series || entry.model || ""}
                                style={{ padding: 8, width: "100%" }}
                            />
                        ) : (
                            <img
                                src={toImageSrc("/img_unknown.png")}
                                alt=""
                                style={{ padding: 8, paddingTop: 10, width: "100%" }}
                            />
                        )}
                    </div>
                }
                actions={[
                    <span
                        onClick={() => onEdit(idx)}
                        style={{ cursor: "pointer" }}
                        onKeyDown={(e) => e.key === "Enter" && onEdit(idx)}
                        role="button"
                        tabIndex={0}
                    >
                        <EditOutlined />
                    </span>,

                    <span
                        onClick={() => onDuplicate(idx)}
                        style={{ cursor: "pointer" }}
                        onKeyDown={(e) => e.key === "Enter" && onDuplicate(idx)}
                        role="button"
                        tabIndex={0}
                    >
                        <CopyOutlined />
                    </span>,
                    <Popconfirm
                        key="del"
                        title={t("tonies.customEditor.deleteConfirm.title")}
                        description={t("tonies.customEditor.deleteConfirm.description", {
                            model: entry.model,
                        })}
                        onConfirm={() => void onDelete(idx)}
                        okText={t("tonies.customEditor.deleteConfirm.confirm")}
                        cancelText={t("tonies.customEditor.deleteConfirm.abort")}
                    >
                        <span
                            style={{ cursor: "pointer", color: token.colorError }}
                            role="button"
                            tabIndex={0}
                        >
                            <DeleteOutlined />
                        </span>
                    </Popconfirm>,
                ]}
            >
                {(() => {
                    const metaTitle = (entry.episodes || "").trim() || undefined;
                    const displayName = (entry.series || entry.model || "").trim();
                    const metaDescription =
                        entry.model && entry.model.trim() !== displayName ? entry.model : undefined;
                    const overrideTag = overriddenModel ? (
                        <Tag
                            color="warning"
                            style={{ border: 0, marginTop: 8, whiteSpace: "normal" }}
                        >
                            {t("tonies.customEditor.overridesOriginal.tag", {
                                model: overriddenModel,
                            })}
                        </Tag>
                    ) : null;
                    if (!metaTitle && !metaDescription) return overrideTag;
                    return (
                        <>
                            <Card.Meta title={metaTitle} description={metaDescription} />
                            {overrideTag}
                        </>
                    );
                })()}
            </Card>
        </div>
    );
};
