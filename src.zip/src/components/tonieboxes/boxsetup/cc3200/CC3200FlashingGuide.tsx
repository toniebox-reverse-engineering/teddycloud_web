import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Button, Divider, Steps, Typography } from "antd";
import { CheckSquareOutlined, EyeOutlined, LeftOutlined, RightOutlined } from "@ant-design/icons";

import { BoxVersionsEnum } from "../../../../types/tonieboxTypes";

import { useAltUrlCustomPatch } from "./hooks/useAltUrlCustomPatch";
import { useAltPortCustomPatch } from "./hooks/useAltPortCustomPatch";
import { isValidAltPort } from "./hooks/altPortPatch";
import { Step0Preparations } from "./steps/Step0Preparations";
import { Step1Bootloader } from "./steps/Step1Bootloader";
import { Step2Certificates } from "./steps/Step2Certificates";
import { Step3Patches } from "./steps/Step3Patches";
import { Step4ApplyingPatches } from "./steps/Step4ApplyingPatches";
import AvailableBoxesModal from "../common/modals/AvailableBoxesModal";
import { scrollToTop } from "../../../../utils/browser/browserUtils";

const { Paragraph } = Typography;

export type HwTool = "uart" | "esp32c3";

export const CC3200BoxFlashingGuide: React.FC = () => {
    const { t } = useTranslation();
    const scrollToTopAnchor = useRef<HTMLDivElement | null>(null);

    const [currentStep, setCurrentStep] = useState(0);
    const [hostname, setHostname] = useState<string>("");
    const [warningTextHostname, setWarningTextHostname] = useState<string>("");
    const [port, setPort] = useState<string>("443");
    const [warningTextPort, setWarningTextPort] = useState<string>("");

    const [hwTool, setHwTool] = useState<HwTool>("uart");

    const [isOpenAvailableBoxesModal, setIsOpenAvailableBoxesModal] = useState(false);

    useEffect(() => {
        scrollToTop(scrollToTopAnchor.current);
    }, [currentStep]);

    const steps = [
        { title: t("tonieboxes.boxFlashingCommon.preparations") },
        { title: t("tonieboxes.cc3200BoxFlashing.bootloader") },
        { title: t("tonieboxes.boxFlashingCommon.certificates") },
        { title: t("tonieboxes.cc3200BoxFlashing.patches") },
        { title: t("tonieboxes.cc3200BoxFlashing.applyingPatches") },
    ];

    const sanitizeHostname = (input: string) => input.replace(/[^a-zA-Z0-9-.]/g, "").trim();

    const handleHostnameChange = (value: string) => {
        const sanitized = sanitizeHostname(value);
        let warningText = "";
        if (sanitized.length > 12) {
            warningText = t("tonieboxes.cc3200BoxFlashing.hostnameTooLong");
        }
        setHostname(sanitized);
        setWarningTextHostname(warningText);
    };

    const handlePortChange = (value: string) => {
        const sanitized = value.replace(/[^0-9]/g, "").slice(0, 5);
        setPort(sanitized);
        setWarningTextPort(
            sanitized && !isValidAltPort(Number(sanitized))
                ? t("tonieboxes.cc3200BoxFlashing.portInvalid")
                : "",
        );
    };

    const portNumber = Number(port);
    const isPortInvalid = !isValidAltPort(portNumber) || portNumber === 443;
    const { createPatch: createPortPatch } = useAltPortCustomPatch(portNumber);
    const { createPatch: createHostNamePatch } = useAltUrlCustomPatch(hostname);

    const prev = () => setCurrentStep((s) => Math.max(0, s - 1));
    const next = () => setCurrentStep((s) => Math.min(steps.length - 1, s + 1));

    const showAvailableBoxesModal = () => setIsOpenAvailableBoxesModal(true);
    const handleAvailableBoxesModalClose = () => setIsOpenAvailableBoxesModal(false);

    const availableBoxesModal = (
        <AvailableBoxesModal
            boxVersion={BoxVersionsEnum.cc3200}
            isOpen={isOpenAvailableBoxesModal}
            onClose={handleAvailableBoxesModalClose}
        />
    );

    const isHostnameInvalid = hostname.length > 12 || hostname.length === 0;

    const renderStepContent = () => {
        switch (currentStep) {
            case 0:
                return <Step0Preparations hwTool={hwTool} onHwToolChange={setHwTool} />;
            case 1:
                return <Step1Bootloader hwTool={hwTool} />;
            case 2:
                return <Step2Certificates hwTool={hwTool} />;
            case 3:
                return (
                    <Step3Patches
                        hostname={hostname}
                        warningTextHostname={warningTextHostname}
                        onHostnameChange={handleHostnameChange}
                        onCreateHostNamePatch={createHostNamePatch}
                        isHostnameInvalid={isHostnameInvalid}
                        port={port}
                        warningTextPort={warningTextPort}
                        onPortChange={handlePortChange}
                        onCreatePortPatch={createPortPatch}
                        isPortInvalid={isPortInvalid}
                    />
                );
            case 4:
                return <Step4ApplyingPatches />;
            default:
                return null;
        }
    };

    const previousButton = (
        <Button icon={<LeftOutlined />} onClick={prev}>
            {t("tonieboxes.cc3200BoxFlashing.previous")}
        </Button>
    );

    const onStepChange = (value: number) => {
        setCurrentStep(value);
    };

    return (
        <>
            <h1 ref={scrollToTopAnchor}>{t("tonieboxes.cc3200BoxFlashing.title")}</h1>
            <Divider>{t("tonieboxes.cc3200BoxFlashing.title")}</Divider>

            <Paragraph>
                <Steps
                    current={currentStep}
                    onChange={onStepChange}
                    items={steps.map((step, index) => ({
                        key: index,
                        title: step.title,
                        status:
                            index === currentStep
                                ? "process"
                                : index < currentStep
                                  ? "finish"
                                  : "wait",
                    }))}
                />

                <div style={{ marginTop: 24 }}>{renderStepContent()}</div>

                <div style={{ marginTop: 24, marginBottom: 24 }}>
                    {currentStep === 0 && (
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                flexWrap: "wrap",
                                gap: 8,
                            }}
                        >
                            <div />
                            <div />
                            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                                <Button icon={<RightOutlined />} iconPlacement="end" onClick={next}>
                                    {t("tonieboxes.cc3200BoxFlashing.proceedWithCustomBootloader")}
                                </Button>
                            </div>
                        </div>
                    )}

                    {currentStep === 1 && (
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                flexWrap: "wrap",
                                gap: 8,
                            }}
                        >
                            {previousButton}
                            <div />
                            <div>
                                <Button
                                    icon={<CheckSquareOutlined />}
                                    type="primary"
                                    onClick={next}
                                >
                                    {t("tonieboxes.cc3200BoxFlashing.bootloaderInstalled")}
                                </Button>
                            </div>
                        </div>
                    )}

                    {currentStep === 2 && (
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                flexWrap: "wrap",
                                gap: 8,
                            }}
                        >
                            {previousButton}
                            <div />
                            <div>
                                <Button
                                    icon={<CheckSquareOutlined />}
                                    type="primary"
                                    onClick={next}
                                >
                                    {t(
                                        "tonieboxes.cc3200BoxFlashing.certificatesDumpedCAreplacementFlashed",
                                    )}
                                </Button>
                            </div>
                        </div>
                    )}

                    {currentStep === 3 && (
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                flexWrap: "wrap",
                                gap: 8,
                            }}
                        >
                            {previousButton}
                            <div></div>
                            <div>
                                <Button icon={<RightOutlined />} iconPlacement="end" onClick={next}>
                                    {t("tonieboxes.cc3200BoxFlashing.next")}
                                </Button>
                            </div>
                        </div>
                    )}

                    {currentStep === 4 && (
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                flexWrap: "wrap",
                                gap: 8,
                            }}
                        >
                            {previousButton}
                            <div>
                                <Button
                                    icon={<EyeOutlined />}
                                    type="primary"
                                    onClick={showAvailableBoxesModal}
                                >
                                    {t("tonieboxes.cc3200BoxFlashing.checkBoxes")}
                                </Button>
                            </div>
                            <div />
                        </div>
                    )}
                </div>
            </Paragraph>

            {availableBoxesModal}
        </>
    );
};
