import { JSX } from "react";
import { Alert, Image, Table, Typography } from "antd";
import { useTranslation } from "react-i18next";

import tbEsp32UartClamp from "../../../../../assets/boxSetup/tb-esp32-uart-clamp.png";
import tbEsp32UartAnalogClamp from "../../../../../assets/boxSetup/esp32_pcb_clamp.png";
import tbEsp32Uart from "../../../../../assets/boxSetup/tb-esp32-uart.png";
import tbEsp32J100 from "../../../../../assets/boxSetup/esp32_j100.png";
import CodeSnippet from "../../../../common/elements/CodeSnippet";
import { Uart3v3Hint } from "../../common/elements/Uart3v3Hint";

const { Paragraph } = Typography;

export function connectESP32Explanation(): JSX.Element {
    const { t } = useTranslation();

    const columns = [
        {
            title: "Toniebox J103",
            dataIndex: "toniebox",
            key: "toniebox",
        },
        {
            title: "UART",
            dataIndex: "uart",
            key: "uart",
        },
    ];

    const data = [
        {
            key: "1",
            toniebox: "TxD",
            uart: "RxD",
        },
        {
            key: "2",
            toniebox: "RxD",
            uart: "TxD",
        },
        {
            key: "3",
            toniebox: "GND",
            uart: "GND",
        },
    ];

    return (
        <>
            <Uart3v3Hint />
            <Paragraph>{t("tonieboxes.connectESP32Modal.connectESP32Text1_1")}</Paragraph>
            <Paragraph
                style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexWrap: "wrap",
                    gap: 16,
                }}
            >
                <Image
                    src={tbEsp32J100}
                    style={{ height: "auto", width: 400, maxWidth: "min(400px, 90%)" }}
                    preview={false}
                    alt={t("tonieboxes.connectESP32Modal.esp32UartJ100")}
                />
            </Paragraph>
            <Paragraph>{t("tonieboxes.connectESP32Modal.connectESP32Text1_2")}</Paragraph>

            <Paragraph
                style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexWrap: "wrap",
                    gap: 16,
                }}
            >
                <Table
                    columns={columns}
                    dataSource={data}
                    size="small"
                    pagination={false}
                    style={{ width: 250, marginBottom: 16 }}
                />

                <Image
                    src={tbEsp32Uart}
                    style={{ height: "auto", width: 240, maxWidth: "min(240px, 90%)" }}
                    preview={false}
                    alt={t("tonieboxes.connectESP32Modal.esp32UartJ103")}
                />
            </Paragraph>
            <h5>{t("tonieboxes.connectESP32Modal.esp32UartJ103ClampTitle")}</h5>
            <Paragraph
                style={{
                    display: "flex",
                    alignItems: "flex-start",
                    justifyContent: "center",
                    flexWrap: "wrap",
                    gap: 16,
                }}
            >
                <Image.PreviewGroup>
                    <div style={{ maxWidth: 200 }}>
                        <Image
                            style={{ height: 200, width: "auto" }}
                            src={tbEsp32UartClamp}
                            alt={t("tonieboxes.connectESP32Modal.esp32UartJ103Clamp")}
                        />
                        <Paragraph style={{ marginTop: 8 }}>
                            {t("tonieboxes.connectESP32Modal.esp32UartJ103Clamp")}
                        </Paragraph>
                    </div>
                    <div style={{ maxWidth: 200 }}>
                        <Image
                            style={{ height: 200, width: "auto" }}
                            src={tbEsp32UartAnalogClamp}
                            alt={t("tonieboxes.connectESP32Modal.esp32UartJ103AnalogClamp")}
                        />
                        <Paragraph style={{ marginTop: 8 }}>
                            {t("tonieboxes.connectESP32Modal.esp32UartJ103AnalogClamp")}
                        </Paragraph>
                    </div>
                </Image.PreviewGroup>
            </Paragraph>
            <Paragraph>{t("tonieboxes.connectESP32Modal.esp32UartJ103Clamp4PinHint")}</Paragraph>

            <Paragraph>{t("tonieboxes.connectESP32Modal.connectESP32Text2")}</Paragraph>
            <Alert
                type="warning"
                title={t("tonieboxes.connectESP32Modal.beware")}
                description={t("tonieboxes.connectESP32Modal.warningText")}
            />

            <h5>{t("tonieboxes.connectESP32Modal.normalMode")}</h5>
            <Paragraph>{t("tonieboxes.connectESP32Modal.normalModeText")}</Paragraph>

            <CodeSnippet
                language="shell"
                code={`ESP-ROM:esp32s3-20210327
Build:Mar 27 2021
rst:0x1 (POWERON),boot:0x8 (SPI_FAST_FLASH_BOOT)
SPIWP:0xee
mode:DIO, clock div:1
load:0x3fcd0108,len:0x118
load:0x403b6000,len:0xb90
load:0x403ba000,len:0x27f4
entry 0x403b61c4
+ gibberish`}
            />

            <h5>{t("tonieboxes.connectESP32Modal.downloadMode")}</h5>
            <Paragraph>{t("tonieboxes.connectESP32Modal.downloadModeText")}</Paragraph>

            <CodeSnippet
                language="shell"
                code={`ESP-ROM:esp32s3-20210327
Build:Mar 27 2021
rst:0x1 (POWERON),boot:0x0 (DOWNLOAD(USB/UART0))
waiting for download
J103 Pinout`}
            />
        </>
    );
}
