import React from "react";
import { Alert, theme, Typography } from "antd";
import { ESP32Flasher } from "../hooks/useESP32Flasher";
import { useTranslation } from "react-i18next";
import DotAnimation from "../../../../../common/elements/DotAnimation";

const { Paragraph } = Typography;
const { useToken } = theme;

interface Step3Props {
    state: ESP32Flasher;
    contentProgress: React.ReactNode;
}

const renderStateWithAnimation = (text: string) => {
    if (text.endsWith("...")) {
        const baseText = text.slice(0, -3);
        return (
            <div style={{ display: "flex" }}>
                {baseText}
                <DotAnimation />
            </div>
        );
    }
    return text;
};

export const Step3FlashESP32: React.FC<Step3Props> = ({ state, contentProgress }) => {
    const { t } = useTranslation();
    const { token } = useToken();

    const stepStatusText = state.showStatus && (
        <div
            className="status"
            style={{ marginBottom: 16, color: state.error ? token.colorErrorText : "unset" }}
        >
            <i>{renderStateWithAnimation(state.state)}</i>
        </div>
    );

    return (
        <>
            <h3>{t("tonieboxes.esp32BoxFlashing.esp32flasher.titleFlashESP32")}</h3>
            {!state.actionInProgress && (
                <Paragraph>
                    <Alert
                        type="info"
                        description={t(
                            "tonieboxes.esp32BoxFlashing.esp32flasher.hintFlashESP32RevvoxFlasher",
                        )}
                    />
                </Paragraph>
            )}
            {stepStatusText}
            {!state.actionInProgress && state.downloadLinkPatched ? (
                <div style={{ marginBottom: 16 }}>
                    <a
                        href={state.downloadLinkPatched}
                        download={"patched_" + state.filename}
                        title={"patched_" + state.filename}
                    >
                        {t("tonieboxes.esp32BoxFlashing.esp32flasher.downloadLinkPatched")}
                    </a>
                </div>
            ) : (
                ""
            )}
            {contentProgress}
        </>
    );
};
