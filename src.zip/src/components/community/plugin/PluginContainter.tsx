import { useEffect, useRef, useState } from "react";
import { Alert, Typography, theme } from "antd";
import { useTranslation } from "react-i18next";
import { useTeddyCloud } from "../../../provider/TeddyCloudProvider";
import { NotificationTypeEnum } from "../../../types/teddyCloudNotificationTypes";
import { withBase } from "../../../utils/basePath";

const { Paragraph } = Typography;
const { useToken } = theme;

interface PluginContainerProps {
    pluginId: string;
}

export const PluginContainer: React.FC<PluginContainerProps> = ({ pluginId }) => {
    const { t } = useTranslation();
    const { token } = useToken();
    const { addNotification } = useTeddyCloud();

    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [isError404, setIsError404] = useState(false);

    useEffect(() => {
        const iframe = iframeRef.current;
        if (!iframe) return;

        let ro: ResizeObserver | null = null;
        let intervalId: number | null = null;
        let hasNotified = false;

        const setHeight = () => {
            if (!iframe.contentWindow) return;

            try {
                const doc = iframe.contentDocument || iframe.contentWindow.document;
                if (!doc) return;

                const isError = doc.getElementById("error-404");
                if (isError) {
                    setIsError404(true);
                    if (!hasNotified) {
                        hasNotified = true;
                        addNotification(
                            NotificationTypeEnum.Error,
                            t("community.plugins.error.notification.title"),
                            t("community.plugins.error.notification.missingPluginIndexHtml", {
                                pluginId,
                            }),
                            t("community.plugins.title"),
                        );
                    }
                    return;
                } else {
                    setIsError404(false);
                }

                const body = doc.body;
                const html = doc.documentElement;
                if (!body || !html) return;

                const height = Math.max(
                    body.scrollHeight,
                    body.offsetHeight,
                    html.scrollHeight,
                    html.offsetHeight,
                    html.clientHeight,
                );

                iframe.style.height = `${height}px`;
            } catch {
                // Cross-origin: cannot measure
            }
        };

        const onLoad = () => {
            setHeight();

            try {
                const doc = iframe.contentDocument || iframe.contentWindow?.document;
                const html = doc?.documentElement;
                if (!doc || !html) return;

                ro?.disconnect();
                ro = new ResizeObserver(() => setHeight());
                ro.observe(html);

                doc.addEventListener("transitionend", setHeight, true);
                doc.addEventListener("animationend", setHeight, true);

                const imgs = Array.from(doc.images || []);
                imgs.forEach((img) => img.addEventListener("load", setHeight, { once: true }));
            } catch {
                // ignore, may be cross-origin
            }

            if (intervalId) window.clearInterval(intervalId);
            intervalId = window.setInterval(setHeight, 300);
        };

        iframe.addEventListener("load", onLoad);

        return () => {
            iframe.removeEventListener("load", onLoad);
            ro?.disconnect();
            ro = null;
            if (intervalId) window.clearInterval(intervalId);
        };
    }, [pluginId, addNotification, t]);

    useEffect(() => {
        setIsError404(false);
        const iframe = iframeRef.current;
        if (!iframe) return;

        const handleLoad = () => {
            const iframeDocument = iframe.contentWindow?.document;
            if (!iframeDocument || !iframeDocument.body || !iframeDocument.head) return;

            const style = iframeDocument.createElement("style");
            style.textContent = `
                #teddycloud-header, #teddycloud-footer, .additional-footer-padding {
                    display: none !important;
                }
                .App {
                    background-color: ${token.colorBgElevated} !important;
                }
                .ant-layout {
                    background: unset;                    
                }
            `;
            iframeDocument.head.appendChild(style);

            iframe.style.height = `${iframeDocument.body.scrollHeight + 48}px`;
        };

        iframe.addEventListener("load", handleLoad);

        return () => {
            iframe.removeEventListener("load", handleLoad);
        };
    }, [pluginId, token.colorBgElevated]);

    return (
        <>
            {isError404 && (
                <Alert
                    type="error"
                    showIcon
                    title={t("community.plugins.error.title")}
                    description={
                        <>
                            <Paragraph>{t("community.plugins.error.pluginNotFound")}</Paragraph>
                        </>
                    }
                    style={{ marginBottom: 16 }}
                />
            )}
            <iframe
                ref={iframeRef}
                src={withBase(`/plugins/${pluginId}/index.html`)}
                title={`${t("community.plugins.plugin")}: ${pluginId}`}
                style={{
                    width: "100%",
                    minHeight: "300px",
                    border: 0,
                    overflow: "hidden",
                }}
                allow="fullscreen"
            />
        </>
    );
};
