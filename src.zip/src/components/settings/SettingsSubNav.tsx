import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Link, useLocation } from "react-router-dom";
import { MenuProps } from "antd";
import {
    SafetyCertificateOutlined,
    SettingOutlined,
    PoweroffOutlined,
    FileSearchOutlined,
    SyncOutlined,
    BellOutlined,
    CodeSandboxOutlined,
    MinusOutlined,
    PlusOutlined,
    ExportOutlined,
    LockOutlined,
    AppstoreOutlined,
} from "@ant-design/icons";

import { TeddyCloudApi } from "../../api";
import { defaultAPIConfig } from "../../config/defaultApiConfig";

import { StyledSubMenu } from "../common/StyledComponents";
import { restartServer } from "../../utils/system/restartTeddyCloud";
import { useTeddyCloud } from "../../provider/TeddyCloudProvider";
import { NotificationTypeEnum } from "../../types/teddyCloudNotificationTypes";
import { TeddyCloudSection } from "../../types/pluginsMetaTypes";

const api = new TeddyCloudApi(defaultAPIConfig());

export const SettingsSubNav = () => {
    const { t, i18n } = useTranslation();
    const {
        setNavOpen,
        setSubNavOpen,
        setCurrentTCSection,
        plugins,
        addNotification,
        addLoadingNotification,
        closeLoadingNotification,
    } = useTeddyCloud();
    const currentLanguage = i18n.language;
    const location = useLocation();
    const [openKeys, setOpenKeys] = useState<string[]>([]);

    useEffect(() => {
        setCurrentTCSection(t("settings.navigationTitle"));
    }, [currentLanguage]);

    const pluginItems = plugins
        .filter((p) => p.teddyCloudSection === TeddyCloudSection.Settings && !p.hideInNav)
        .map((plugin) => ({
            key: `plugin-${plugin.pluginId}`,
            label: (
                <Link
                    to={
                        plugin.standalone
                            ? `/plugin/${plugin.pluginId}`
                            : `/settings/plugin/${plugin.pluginId}`
                    }
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                    target={plugin.standalone ? "_blank" : "_self"}
                >
                    {plugin.pluginName}
                    {plugin.standalone ? (
                        <ExportOutlined
                            style={{ marginLeft: 2, fontSize: 6, bottom: 6, position: "relative" }}
                        />
                    ) : (
                        ""
                    )}
                </Link>
            ),
            icon: React.createElement(CodeSandboxOutlined),

            title: plugin.pluginName,
        }));

    const handleRestartServer = async () => {
        await restartServer(
            t,
            true,
            addNotification,
            addLoadingNotification,
            closeLoadingNotification,
        );
    };

    const handleReloadToniesJson = async () => {
        const key = "reloadToniesJson";
        addLoadingNotification(
            key,
            t("settings.toniesJsonUpdate"),
            t("settings.toniesJsonUpdateInProgress"),
        );

        try {
            const response = await api.apiGetTeddyCloudApiRaw("/api/toniesJsonUpdate");
            const data = await response.text();

            closeLoadingNotification(key);
            if (data.toString() !== "Triggered tonies.json update") {
                addNotification(
                    NotificationTypeEnum.Error,
                    t("settings.toniesJsonUpdateFailed"),
                    t("settings.toniesJsonUpdateFailed") + ": " + data.toString(),
                    t("settings.navigationTitle"),
                );
            } else {
                addNotification(
                    NotificationTypeEnum.Success,
                    t("settings.toniesJsonUpdateSuccessful"),
                    t("settings.toniesJsonUpdateSuccessful"),
                    t("settings.navigationTitle"),
                );
            }
        } catch (error) {
            addNotification(
                NotificationTypeEnum.Error,
                t("settings.toniesJsonUpdateFailed"),
                t("settings.toniesJsonUpdateFailed") + ": " + error,
                t("settings.navigationTitle"),
            );
        }
    };

    const updateOpenKeys = (pathname: string) => {
        const newKeys: string[] = [];

        if (pathname.includes("/settings/guisettings")) {
            newKeys.push("general");
            newKeys.push("guisettings");
        }
        if (pathname.includes("/settings/webauth")) {
            newKeys.push("general");
            newKeys.push("webauth");
        }
        setOpenKeys((prevKeys) => Array.from(new Set([...prevKeys, ...newKeys])));
    };

    useEffect(() => {
        updateOpenKeys(location.pathname);
    }, [location.pathname]);

    const onOpenChange = (keys: string[]) => {
        const latestOpenKey = keys.find((key) => !openKeys.includes(key)); // New key being opened
        const latestCloseKey = openKeys.find((key) => !keys.includes(key)); // Key being closed

        if (latestOpenKey) {
            setOpenKeys((prevKeys) => [...prevKeys, latestOpenKey]);
        } else if (latestCloseKey) {
            setOpenKeys((prevKeys) => prevKeys.filter((key) => key !== latestCloseKey));
        }
    };

    const customExpandIcon = ({ isOpen }: { isOpen?: boolean }) => {
        const isExpanded = isOpen ?? false;
        return isExpanded ? (
            <MinusOutlined style={{ margin: "16px 0 16px 16px" }} />
        ) : (
            <PlusOutlined style={{ margin: "16px 0 16px 16px" }} />
        );
    };

    const subnav: MenuProps["items"] = [
        {
            key: "general",
            label: (
                <Link
                    to="/settings"
                    style={{
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        color: "currentColor",
                    }}
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("settings.general.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(SettingOutlined),
            title: t("settings.general.navigationTitle"),
            children: [
                {
                    key: "guisettings",
                    label: (
                        <Link
                            to="/settings/guisettings"
                            onClick={() => {
                                setNavOpen(false);
                                setSubNavOpen(false);
                            }}
                        >
                            {t("settings.guiSettings.navigationTitle")}
                        </Link>
                    ),
                    icon: React.createElement(SettingOutlined),
                    title: t("settings.guiSettings.navigationTitle"),
                },
                {
                    key: "webauth",
                    label: (
                        <Link
                            to="/settings/webauth"
                            onClick={() => {
                                setNavOpen(false);
                                setSubNavOpen(false);
                            }}
                        >
                            {t("settings.webAuth.navigationTitle")}
                        </Link>
                    ),
                    icon: React.createElement(LockOutlined),
                    title: t("settings.webAuth.navigationTitle"),
                },
            ],
        },
        {
            key: "certificates",
            label: (
                <Link
                    to="/settings/certificates"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("settings.certificates.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(SafetyCertificateOutlined),
            title: t("settings.certificates.navigationTitle"),
        },
        {
            key: "tcplugins",
            label: (
                <Link
                    to="/community/tcplugins"
                    style={{
                        color: "currentColor",
                        display: "flex",
                        alignItems: "center",
                        padding: "0 50px 0 0",
                    }}
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("community.plugins.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(AppstoreOutlined),
            title: t("community.plugins.navigationTitle"),
        },
        {
            key: "rtnl",
            label: (
                <Link
                    to="/settings/rtnl"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("settings.rtnl.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(FileSearchOutlined),
            title: t("settings.rtnl.navigationTitle"),
        },
        {
            key: "notifications",
            label: (
                <Link
                    to="/settings/notifications"
                    onClick={() => {
                        setNavOpen(false);
                        setSubNavOpen(false);
                    }}
                >
                    {t("settings.notifications.navigationTitle")}
                </Link>
            ),
            icon: React.createElement(BellOutlined),
            title: t("settings.notifications.navigationTitle"),
        },
        {
            key: "reload_toniesJson",
            label: <label style={{ cursor: "pointer" }}>{t("settings.toniesJsonUpdate")}</label>,
            onClick: () => {
                handleReloadToniesJson();
                setNavOpen(false);
                setSubNavOpen(false);
            },
            icon: React.createElement(SyncOutlined),
            title: t("settings.toniesJsonUpdate"),
        },
        {
            key: "restart_server",
            label: <label style={{ cursor: "pointer" }}>{t("settings.restartServer")}</label>,
            onClick: () => {
                handleRestartServer();
                setNavOpen(false);
                setSubNavOpen(false);
            },
            icon: React.createElement(PoweroffOutlined),
            title: t("settings.restartServer"),
        },
        ...pluginItems,
    ];

    return (
        <StyledSubMenu
            mode="inline"
            defaultOpenKeys={["sub"]}
            openKeys={openKeys}
            selectedKeys={[]}
            onOpenChange={onOpenChange}
            items={subnav}
            expandIcon={({ isOpen }) => customExpandIcon({ isOpen })}
        />
    );
};
